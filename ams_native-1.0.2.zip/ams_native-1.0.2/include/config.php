<?php
$host     = "localhost";    // Nama host
$username = "root";         // Username database
$password = "masrud.com";   // Password database
$database = "ams_native";   // Nama database
